>Thank you for your feedback!Please add below details so that we can help you a bit faster.

---

### Agreements
>Please check the below checkboxes to make sure that you are not spamming

---

- [ ] <b>I have read and accepted the [guidelines](https://github.com/VladThodo/behe-explorer/blob/development/CONTRIBUTING.md) for contributing to this project.</b>
- [ ] <b>I have checked the [open issues](https://github.com/VladThodo/behe-explorer/issues) and made shure that this is not a duplicate.</b>

---

### Short description
>Please add a short dscription of the issue.The description should contain:

---

 * BeHe ExloreR version:
 * Android version that you are using:

---

### Reproduction
>Please tell us how to reproduce this issue.

---

### Screenshots
>If you have any screenshots that can help please add them here 

---

 
 



