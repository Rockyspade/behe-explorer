<b>How to contribute</b>
<hr>
<p>1.Fork this repository and optionally give it a star</p>
<p>2.Commit your changes in whatever branch of the forked repo you want</p>
<p>3.Submit a pull request to the development branch of the main repo</p>
<hr>
<p><b>Coding style</b></p>
It's not exactly necessary to keep your code clean,but it helps a lot,so please do it!
<hr>
<p><b>Issues</b></p>
<hr>
<p>1.When writing the description of the issue please be as explicit as possible</p>
<p>2.Check if your issue haven't alerady been submited!</p>
<hr>
<p><b>Feature requests</b></p>
<p>1.Please post your feature requests in the issue section</p>
<p>2.Explain what do you want/need that feature</p>

